# La Cofra de la Gaza

Sitio web turístico con reservas por teléfono y formulario de contacto.

## Instrucciones

```bash
npm install
npm run dev
```

Abre http://localhost:3000