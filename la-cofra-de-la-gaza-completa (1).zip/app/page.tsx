
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import Image from "next/image";

export default function LaCofraDeLaGaza() {
  const [form, setForm] = useState({ nombre: "", email: "", mensaje: "" });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Formulario enviado. Nos pondremos en contacto contigo pronto.");
    setForm({ nombre: "", email: "", mensaje: "" });
  };

  return (
    <div className="min-h-screen bg-blue-50 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-blue-900">La Cofra de la Gaza</h1>
        <p className="text-lg text-blue-700">Pesca y paseos por la bahía de Santander</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <Image
          src="/images/bahia-santander.jpg"
          alt="Bahía de Santander"
          width={600}
          height={400}
          className="rounded-2xl shadow-xl"
        />

        <Card className="bg-white shadow-lg p-4">
          <CardContent>
            <h2 className="text-xl font-semibold text-blue-800 mb-4">Reserva por teléfono</h2>
            <p className="text-gray-700 text-sm mb-2">Para reservar una salida, llámanos directamente:</p>
            <p className="text-blue-900 font-bold text-lg">📞 600 123 456</p>
          </CardContent>
        </Card>
      </section>

      <section className="mt-12">
        <h2 className="text-2xl font-bold text-blue-900 mb-4">¿Qué ofrecemos?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-4">
            <CardContent>
              <h3 className="text-lg font-semibold text-blue-800">Salidas de pesca</h3>
              <p className="text-sm text-gray-600">Organizamos salidas para pesca deportiva y tradicional con guías expertos.</p>
            </CardContent>
          </Card>
          <Card className="p-4">
            <CardContent>
              <h3 className="text-lg font-semibold text-blue-800">Paseos turísticos</h3>
              <p className="text-sm text-gray-600">Descubre la bahía de Santander en un paseo en barco inolvidable.</p>
            </CardContent>
          </Card>
          <Card className="p-4">
            <CardContent>
              <h3 className="text-lg font-semibold text-blue-800">Eventos privados</h3>
              <p className="text-sm text-gray-600">También ofrecemos alquiler de embarcaciones para eventos especiales.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mt-16 max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold text-blue-900 mb-4 text-center">Contacto</h2>
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-2xl shadow-md">
          <div>
            <Label htmlFor="nombre">Nombre</Label>
            <Input id="nombre" name="nombre" value={form.nombre} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" value={form.email} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="mensaje">Mensaje</Label>
            <Textarea id="mensaje" name="mensaje" value={form.mensaje} onChange={handleChange} required />
          </div>
          <Button type="submit" className="w-full">Enviar mensaje</Button>
        </form>
      </section>

      <footer className="mt-16 text-center text-sm text-blue-600">
        © 2025 La Cofra de la Gaza. Todos los derechos reservados.
      </footer>
    </div>
  );
}
